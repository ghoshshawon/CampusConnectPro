<!DOCTYPE html>
<html lang="en-US">


<!-- Mirrored from hrkit.rometheme.pro/zevone/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 08 Jun 2024 16:17:37 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="profile" href="http://gmpg.org/xfn/11" />
    <link rel="pingback" href="xmlrpc.php" />
    	<title>Nexus Institute of Engineering & Sciences</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='http://cdnjs.cloudflare.com/' />
<link rel="alternate" type="application/rss+xml" title="Zevone &raquo; Feed" href="feed/index.html" />
<link rel="alternate" type="application/rss+xml" title="Zevone &raquo; Comments Feed" href="comments/feed/index.html" />
<script>
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/hrkit.rometheme.pro\/zevone\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.5.4"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
</script>
<style id='wp-emoji-styles-inline-css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<style id='classic-theme-styles-inline-css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='template-kit-export-css' href='<?=base_url("assets/");?>wp-content/plugins/template-kit-export/public/assets/css/template-kit-export-public.min365c.css?ver=1.0.21' media='all' />
<link rel='stylesheet' id='rkit-offcanvas-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/offcanvasc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-navmenu-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/navmenuc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-headerinfo-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/headerinfoc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='navmenu-rkit-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/rkit-navmenuc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-search-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/searchc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-blog-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/rkit-blog-postc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-cta-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/ctac2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-blockquote-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/blockquotec2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-social-share-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/social_sharec2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-team-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/rkit_teamc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-running_text-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/running_textc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-animated_heading-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/animated_headingc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-card_slider-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/card_sliderc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-accordion-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/accordionc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-testimonial_carousel-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/testimonial_carouselc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-swiper-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/swiper-bundle.minc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-tabs-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/tabsc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-progress-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/progress-barc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='counter-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/widgets/assets/css/counterc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='elementor-icons-rtmicon-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/assets/css/rtmiconsc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='rkit-widget-style-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/assets/css/rkitc2d0.css?ver=1.4.4' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-grid-style-css' href='<?=base_url("assets/");?>wp-content/plugins/qi-addons-for-elementor/assets/css/grid.minba3a.css?ver=1.7.2' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-helper-parts-style-css' href='<?=base_url("assets/");?>wp-content/plugins/qi-addons-for-elementor/assets/css/helper-parts.minba3a.css?ver=1.7.2' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-style-css' href='<?=base_url("assets/");?>wp-content/plugins/qi-addons-for-elementor/assets/css/main.minba3a.css?ver=1.7.2' media='all' />
<link rel='stylesheet' id='rtform-text-style-css' href='<?=base_url("assets/");?>wp-content/plugins/romethemeform/widgets/assets/css/rtform_text3ec8.css?ver=1.1.6' media='all' />
<link rel='stylesheet' id='rform-style-css' href='<?=base_url("assets/");?>wp-content/plugins/romethemeform/widgets/assets/css/rform3ec8.css?ver=1.1.6' media='all' />
<link rel='stylesheet' id='spinner-style-css' href='<?=base_url("assets/");?>wp-content/plugins/romethemeform/widgets/assets/css/spinner-loading3ec8.css?ver=1.1.6' media='all' />
<link rel='stylesheet' id='rform-btn-style-css' href='<?=base_url("assets/");?>wp-content/plugins/romethemeform/widgets/assets/css/rform-button3ec8.css?ver=1.1.6' media='all' />
<link rel='stylesheet' id='rform-select-style-css' href='<?=base_url("assets/");?>wp-content/plugins/romethemeform/widgets/assets/css/rform-select3ec8.css?ver=1.1.6' media='all' />
<link rel='stylesheet' id='rform-radiobutton-style-css' href='<?=base_url("assets/");?>wp-content/plugins/romethemeform/widgets/assets/css/rform-radiobutton3ec8.css?ver=1.1.6' media='all' />
<link rel='stylesheet' id='rform-checkbox-style-css' href='<?=base_url("assets/");?>wp-content/plugins/romethemeform/widgets/assets/css/rform-checkbox3ec8.css?ver=1.1.6' media='all' />
<link rel='stylesheet' id='intlTelInput-css' href='<?=base_url("assets/");?>wp-content/plugins/romethemeform/widgets/assets/css/intlTelInput3ec8.css?ver=1.1.6' media='all' />
<link rel='stylesheet' id='hello-elementor-css' href='<?=base_url("assets/");?>wp-content/themes/hello-elementor/style.min41fe.css?ver=3.0.1' media='all' />
<link rel='stylesheet' id='hello-elementor-theme-style-css' href='<?=base_url("assets/");?>wp-content/themes/hello-elementor/theme.min41fe.css?ver=3.0.1' media='all' />
<link rel='stylesheet' id='hello-elementor-header-footer-css' href='<?=base_url("assets/");?>wp-content/themes/hello-elementor/header-footer.min41fe.css?ver=3.0.1' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='<?=base_url("assets/");?>wp-content/plugins/elementor/assets/css/frontend-lite.min3cad.css?ver=3.21.8' media='all' />
<link rel='stylesheet' id='elementor-post-3-css' href='<?=base_url("assets/");?>wp-content/uploads/sites/89/elementor/css/post-3ec57.css?ver=1716992072' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='<?=base_url("assets/");?>wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.mind54b.css?ver=5.29.0' media='all' />
<link rel='stylesheet' id='swiper-css' href='<?=base_url("assets/");?>wp-content/plugins/elementor/assets/lib/swiper/v8/css/swiper.min94a4.css?ver=8.4.5' media='all' />
<link rel='stylesheet' id='elementor-post-2664-css' href='<?=base_url("assets/");?>wp-content/uploads/sites/89/elementor/css/post-26646dda.css?ver=1716977899' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CHeebo%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CBarlow%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=auto&amp;ver=6.5.4' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css' href='<?=base_url("assets/");?>wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min52d5.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css' href='<?=base_url("assets/");?>wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min52d5.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-regular-css' href='<?=base_url("assets/");?>wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min52d5.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-brands-css' href='<?=base_url("assets/");?>wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min52d5.css?ver=5.15.3' media='all' />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin><script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/offcanvas380f.js?ver=6.5.4" id="rkit-offcanvas-script-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/navmenu380f.js?ver=6.5.4" id="rkit-navmenu-script-js"></script>
<script src="<?=base_url('assets/');?>wp-includes/js/jquery/jquery.minf43b.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="<?=base_url('assets/');?>wp-includes/js/jquery/jquery-migrate.min5589.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/card_sliderc2d0.js?ver=1.4.4" id="card-slider-script-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/animated_headingc2d0.js?ver=1.4.4" id="animated-heading-script-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/accordionc2d0.js?ver=1.4.4" id="accordion-script-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/bar_chartc2d0.js?ver=1.4.4" id="bar_chart-script-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/line_chartc2d0.js?ver=1.4.4" id="line_chart-script-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/pie_chartc2d0.js?ver=1.4.4" id="pie_chart-script-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/swiper-bundle.minc2d0.js?ver=1.4.4" id="swiperjs-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/romethemeform/widgets/assets/js/rtform_text3ec8.js?ver=1.1.6" id="rtform-text-js-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/romethemeform/widgets/assets/js/rform_select3ec8.js?ver=1.1.6" id="rform-select-js-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/romethemeform/widgets/assets/js/rform_tel_input3ec8.js?ver=1.1.6" id="rform-phone-js-js"></script>
<script id="rform-script-js-extra">
var romethemeform_ajax_url = {"ajax_url":"https:\/\/hrkit.rometheme.pro\/zevone\/wp-admin\/admin-ajax.php","nonce":"1c0312ac08"};
</script>
<script src="<?=base_url('assets/');?>wp-content/plugins/romethemeform/widgets/assets/js/rform3ec8.js?ver=1.1.6" id="rform-script-js"></script>
<script id="intl-tel-input-js-extra">
var intl_tel_input_script = {"url":"https:\/\/hrkit.rometheme.pro\/zevone\/wp-content\/plugins\/romethemeform\/widgets\/assets\/js\/intl_tel_input_utils.js"};
</script>
<script src="<?=base_url('assets/');?>wp-content/plugins/romethemeform/widgets/assets/js/intl_tel_input.min3ec8.js?ver=1.1.6" id="intl-tel-input-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/template-kit-export/public/assets/js/template-kit-export-public.min365c.js?ver=1.0.21" id="template-kit-export-js"></script>
<link rel="https://api.w.org/" href="<?=base_url('assets/');?>wp-json/index.html" /><link rel="alternate" type="application/json" href="<?=base_url('assets/');?>wp-json/wp/v2/pages/2664.json" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.php?rsd" />
<meta name="generator" content="WordPress 6.5.4" />
<link rel="canonical" href="index.html" />
<link rel='shortlink' href='index.html' />
<link rel="alternate" type="application/json+oembed" href="<?=base_url('assets/');?>wp-json/oembed/1.0/embedbf3a.json?url=https%3A%2F%2Fhrkit.rometheme.pro%2Fzevone%2F" />
<link rel="alternate" type="text/xml+oembed" href="<?=base_url('assets/');?>wp-json/oembed/1.0/embedc945?url=https%3A%2F%2Fhrkit.rometheme.pro%2Fzevone%2F&amp;format=xml" />
<meta name="generator" content="Elementor 3.21.8; features: e_optimized_assets_loading, e_optimized_css_loading, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-auto">
</head>

<body class="home page-template page-template-elementor_header_footer page page-id-2664 qodef-qi--no-touch qi-addons-for-elementor-1.7.2 elementor-default elementor-template-full-width elementor-kit-3 elementor-page elementor-page-2664">
        <div id="page">
        <!--Header--><?php include "header.php"?>	<div data-elementor-type="wp-page" data-elementor-id="2664" class="elementor elementor-2664">
				<div class="elementor-element elementor-element-1e97e1b e-flex e-con-boxed e-con e-parent" data-id="1e97e1b" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;shape_divider_bottom&quot;:&quot;curve&quot;,&quot;shape_divider_bottom_negative&quot;:&quot;yes&quot;}">
					<div class="e-con-inner">
				<div class="elementor-shape elementor-shape-bottom" data-negative="true">
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
	<path class="elementor-shape-fill" d="M500,97C126.7,96.3,0.8,19.8,0,0v100l1000,0V1C1000,19.4,873.3,97.8,500,97z"/>
</svg>		</div>
		<div class="elementor-element elementor-element-05791cb e-flex e-con-boxed elementor-invisible e-con e-child" data-id="05791cb" data-element_type="container" data-settings="{&quot;animation&quot;:&quot;fadeInLeft&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-0a85565 elementor-widget elementor-widget-heading" data-id="0a85565" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-heading-title{padding:0;margin:0;line-height:1}.elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a{color:inherit;font-size:inherit;line-height:inherit}.elementor-widget-heading .elementor-heading-title.elementor-size-small{font-size:15px}.elementor-widget-heading .elementor-heading-title.elementor-size-medium{font-size:19px}.elementor-widget-heading .elementor-heading-title.elementor-size-large{font-size:29px}.elementor-widget-heading .elementor-heading-title.elementor-size-xl{font-size:39px}.elementor-widget-heading .elementor-heading-title.elementor-size-xxl{font-size:59px}</style><h6 class="elementor-heading-title elementor-size-default">Nexus Institute of Engineering & Sciences</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-a5fefbf elementor-widget elementor-widget-heading" data-id="a5fefbf" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h4 class="elementor-heading-title " >NAAC 'A' Accredited | NIRF Ranked College &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Affialiated By MAKAUT</h4>		</div>
				</div>
				<div class="elementor-element elementor-element-ca27631 elementor-widget elementor-widget-text-editor" data-id="ca27631" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap{background-color:#69727d;color:#fff}.elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap{color:#69727d;border:3px solid;background-color:transparent}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap{margin-top:8px}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap-letter{width:1em;height:1em}.elementor-widget-text-editor .elementor-drop-cap{float:left;text-align:center;line-height:1;font-size:50px}.elementor-widget-text-editor .elementor-drop-cap-letter{display:inline-block}</style>				<p>Nexus Institute of Engineering and Science, a premier fictional institution, offers cutting-edge programs in engineering and technology. Renowned for innovative research and a vibrant campus life, Nexus shapes future leaders and pioneers in the ever-evolving tech landscape.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-38e688a elementor-widget elementor-widget-spacer" data-id="38e688a" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-column .elementor-spacer-inner{height:var(--spacer-size)}.e-con{--container-widget-width:100%}.e-con-inner>.elementor-widget-spacer,.e-con>.elementor-widget-spacer{width:var(--container-widget-width,var(--spacer-size));--align-self:var(--container-widget-align-self,initial);--flex-shrink:0}.e-con-inner>.elementor-widget-spacer>.elementor-widget-container,.e-con>.elementor-widget-spacer>.elementor-widget-container{height:100%;width:100%}.e-con-inner>.elementor-widget-spacer>.elementor-widget-container>.elementor-spacer,.e-con>.elementor-widget-spacer>.elementor-widget-container>.elementor-spacer{height:100%}.e-con-inner>.elementor-widget-spacer>.elementor-widget-container>.elementor-spacer>.elementor-spacer-inner,.e-con>.elementor-widget-spacer>.elementor-widget-container>.elementor-spacer>.elementor-spacer-inner{height:var(--container-widget-height,var(--spacer-size))}.e-con-inner>.elementor-widget-spacer.elementor-widget-empty,.e-con>.elementor-widget-spacer.elementor-widget-empty{position:relative;min-height:22px;min-width:22px}.e-con-inner>.elementor-widget-spacer.elementor-widget-empty .elementor-widget-empty-icon,.e-con>.elementor-widget-spacer.elementor-widget-empty .elementor-widget-empty-icon{position:absolute;top:0;bottom:0;left:0;right:0;margin:auto;padding:0;width:22px;height:22px}</style>		<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-184e89d elementor-tablet-align-center elementor-mobile-align-center elementor-widget elementor-widget-button" data-id="184e89d" data-element_type="widget" data-widget_type="button.default" style="color: black;">
				<div class="elementor-widget-container" >
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-lg" href="#">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-icon elementor-align-icon-left" >
				
									<span class="elementor-button-text">Apply For Online Admission</span>
					</span>
					</a>
		</div>
				</div>
				</div>
				<!--<div class="elementor-element elementor-element-0e89679 elementor-widget elementor-widget-heading" data-id="0e89679" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default">Avail a free 30 minutes one-on-one online (live) <br>
trial lesson for your instrument. </p>		</div>
				</div>-->
					</div>
				</div>
		<div class="elementor-element elementor-element-7736836 e-con-full e-flex e-con e-child" data-id="7736836" data-element_type="container">
				<div class="elementor-element elementor-element-9a61182 elementor-widget elementor-widget-image" data-id="9a61182" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img fetchpriority="high" decoding="async" width="751" height="941" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/photo-3-1.png" class="attachment-full size-full wp-image-740" alt=""  sizes="(max-width: 751px) 100vw, 751px" />													</div>
				</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-49b7b01 e-flex e-con-boxed e-con e-parent" data-id="49b7b01" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-9e57a91 e-flex e-con-boxed e-con e-child" data-id="9e57a91" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-4e4f2cb elementor-view-framed elementor-position-left elementor-vertical-align-middle elementor-mobile-position-left elementor-shape-circle elementor-widget elementor-widget-icon-box" data-id="4e4f2cb" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
			<link rel="stylesheet" href="<?=base_url('assets/');?>wp-content/plugins/elementor/assets/css/widget-icon-box.min.css">		<div class="elementor-icon-box-wrapper">

						<div class="elementor-icon-box-icon">
				<span  class="elementor-icon elementor-animation-">
				<i aria-hidden="true" class="fas fa-play"></i>				</span>
			</div>
			
						<div class="elementor-icon-box-content">

									<h5 class="elementor-icon-box-title">
						<span  >
							WATCH NOW						</span>
					</h5>
				
									<p class="elementor-icon-box-description">
						INTRODUCING STUDIO					</p>
				
			</div>
			
		</div>
				</div>
				</div>
					</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-d7dbd8c e-flex e-con-boxed e-con e-parent" data-id="d7dbd8c" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-766b164 e-flex e-con-boxed e-con e-child" data-id="766b164" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-24ba217 e-flex e-con-boxed e-con e-child" data-id="24ba217" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-5186794 e-flex e-con-boxed e-con e-child" data-id="5186794" data-element_type="container">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-137134e elementor-invisible elementor-widget elementor-widget-image" data-id="137134e" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInDown&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img decoding="async" width="611" height="941" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/photo-4.jpg" class="attachment-full size-full wp-image-750" alt=""  sizes="(max-width: 611px) 100vw, 611px" />													</div>
				</div>
				<div class="elementor-element elementor-element-200e9e9 elementor-invisible elementor-widget elementor-widget-image" data-id="200e9e9" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInLeft&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img loading="lazy" decoding="async" width="1920" height="1280" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/photo-6.jpg" class="attachment-full size-full wp-image-755" alt=""  sizes="(max-width: 1920px) 100vw, 1920px" />													</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-9900fdf e-con-full e-flex e-con e-child" data-id="9900fdf" data-element_type="container">
				<div class="elementor-element elementor-element-4a89bcb elementor-widget elementor-widget-spacer" data-id="4a89bcb" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-5186794 e-flex e-con-boxed e-con e-child" data-id="5186794" data-element_type="container">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-137134e elementor-invisible elementor-widget elementor-widget-image" data-id="137134e" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInDown&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
													
													<img decoding="async" width="611" height="941" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/photo-5.jpg" class="attachment-full size-full wp-image-750" alt=""  sizes="(max-width: 611px) 100vw, 611px" />													</div>
				</div>
				
					</div>
				</div>
				</div>
					</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-1fc828a e-con-full e-flex e-con e-child" data-id="1fc828a" data-element_type="container">
				<div class="elementor-element elementor-element-a4473a8 elementor-widget elementor-widget-heading" data-id="a4473a8" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">Nexus Institute of Engineering & Sciences</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-6a2143f elementor-widget elementor-widget-heading" data-id="6a2143f" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default" style="color:#fff;">Welcome to Nexus Institute of Engineering & Sciences</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-061eda5 elementor-widget elementor-widget-text-editor" data-id="061eda5" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Nexus Institute of Engineering & Sciences is a premier educational institution dedicated to nurturing future leaders in engineering and technology. Our mission is to provide high-quality education through a blend of rigorous academics and hands-on experience. With state-of-the-art facilities, experienced faculty, and a commitment to innovation, we empower students to excel in their fields. At Nexus, we foster a dynamic learning environment that encourages creativity, critical thinking, and problem-solving skills. Join us to be part of a vibrant community focused on driving technological advancements and making a positive impact on the world.</p>						</div>
				</div>
		<div class="elementor-element elementor-element-b4466de e-flex e-con-boxed e-con e-child" data-id="b4466de" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-1f36207 e-flex e-con-boxed e-con e-child" data-id="1f36207" data-element_type="container">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-3629b5a elementor-view-framed elementor-position-left elementor-vertical-align-middle elementor-mobile-position-left elementor-shape-circle elementor-widget elementor-widget-icon-box" data-id="3629b5a" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">

						<div class="elementor-icon-box-icon">
				<span  class="elementor-icon elementor-animation-">
				<i aria-hidden="true" class="fas fa-check-circle"></i>				</span>
			</div>
			
						<div class="elementor-icon-box-content">

									<h6 class="elementor-icon-box-title">
						<span  >
							JOB ASSURANCE				</span>
					</h6>
				
				
			</div>
			
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-6cd0494 elementor-view-framed elementor-position-left elementor-vertical-align-middle elementor-mobile-position-left elementor-shape-circle elementor-widget elementor-widget-icon-box" data-id="6cd0494" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">

						<div class="elementor-icon-box-icon">
				<span  class="elementor-icon elementor-animation-">
				<i aria-hidden="true" class="fas fa-check-circle"></i>				</span>
			</div>
			
						<div class="elementor-icon-box-content">

									<h6 class="elementor-icon-box-title">
						<span  >
							EXPERIENCED FACILITY						</span>
					</h6>
				
				
			</div>
			
		</div>
				</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-8ab96ef e-con-full e-flex e-con e-child" data-id="8ab96ef" data-element_type="container">
				<div class="elementor-element elementor-element-64918a8 elementor-view-framed elementor-position-left elementor-vertical-align-middle elementor-mobile-position-left elementor-shape-circle elementor-widget elementor-widget-icon-box" data-id="64918a8" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">

						<div class="elementor-icon-box-icon">
				<span  class="elementor-icon elementor-animation-">
				<i aria-hidden="true" class="fas fa-check-circle"></i>				</span>
			</div>
			
						<div class="elementor-icon-box-content">

									<h6 class="elementor-icon-box-title">
						<span  >
							ON CAMPUS INTERNSHIP 						</span>
					</h6>
				
				
			</div>
			
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-594511e elementor-view-framed elementor-position-left elementor-vertical-align-middle elementor-tablet-position-left elementor-mobile-position-left elementor-shape-circle elementor-widget elementor-widget-icon-box" data-id="594511e" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">

						<div class="elementor-icon-box-icon">
				<span  class="elementor-icon elementor-animation-">
				<i aria-hidden="true" class="fas fa-check-circle"></i>				</span>
			</div>
			
						<div class="elementor-icon-box-content">

									<h6 class="elementor-icon-box-title">
						<span  >
							MODERNIZED LABS						</span>
					</h6>
				
				
			</div>
			
		</div>
				</div>
				</div>
				</div>
					</div>
				</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-3f6e667 e-flex e-con-boxed e-con e-parent" data-id="3f6e667" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-a2a6d51 elementor-widget elementor-widget-heading" data-id="a2a6d51" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default" >COURSES</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-277cc11 elementor-widget elementor-widget-heading" data-id="277cc11" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default" style="color:#fff;">Explore Our Diverse Course Offerings</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-ef90f5a elementor-widget elementor-widget-text-editor" data-id="ef90f5a" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p> Nexus Institute of Engineering & Sciences offers comprehensive undergraduate and postgraduate courses in Engineering, Computer Science, and Business Administration, with cutting-edge labs, experienced faculty, and industry partnerships to foster innovation, practical skills, and career readiness.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-5ebc59b elementor-widget elementor-widget-spacer" data-id="5ebc59b" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
		<div class="elementor-element elementor-element-9f9c97f e-flex e-con-boxed e-con e-child" data-id="9f9c97f" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-21be99c e-flex e-con-boxed elementor-invisible e-con e-child" data-id="21be99c" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInUp&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-832380f e-flex e-con-boxed e-con e-child" data-id="832380f" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-8391b92 elementor-position-top elementor-widget elementor-widget-image-box" data-id="8391b92" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-widget-image-box .elementor-image-box-content{width:100%}@media (min-width:768px){.elementor-widget-image-box.elementor-position-left .elementor-image-box-wrapper,.elementor-widget-image-box.elementor-position-right .elementor-image-box-wrapper{display:flex}.elementor-widget-image-box.elementor-position-right .elementor-image-box-wrapper{text-align:end;flex-direction:row-reverse}.elementor-widget-image-box.elementor-position-left .elementor-image-box-wrapper{text-align:start;flex-direction:row}.elementor-widget-image-box.elementor-position-top .elementor-image-box-img{margin:auto}.elementor-widget-image-box.elementor-vertical-align-top .elementor-image-box-wrapper{align-items:flex-start}.elementor-widget-image-box.elementor-vertical-align-middle .elementor-image-box-wrapper{align-items:center}.elementor-widget-image-box.elementor-vertical-align-bottom .elementor-image-box-wrapper{align-items:flex-end}}@media (max-width:767px){.elementor-widget-image-box .elementor-image-box-img{margin-left:auto!important;margin-right:auto!important;margin-bottom:15px}}.elementor-widget-image-box .elementor-image-box-img{display:inline-block}.elementor-widget-image-box .elementor-image-box-title a{color:inherit}.elementor-widget-image-box .elementor-image-box-wrapper{text-align:center}.elementor-widget-image-box .elementor-image-box-description{margin:0}</style><div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img loading="lazy" decoding="async" width="300" height="300" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/icon-6-1.png" class="elementor-animation-grow attachment-full size-full wp-image-1353" alt=""  sizes="(max-width: 300px) 100vw, 300px" /></figure><div class="elementor-image-box-content"><h5 class="elementor-image-box-title">BTech</h5><p class="elementor-image-box-description">A comprehensive undergraduate program that covers various engineering disciplines, providing hands-on experience and theoretical knowledge to prepare students for a successful engineering career</p></div></div>		</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-8b695a9 e-flex e-con-boxed e-con e-child" data-id="8b695a9" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-7ac53e1 elementor-position-top elementor-widget elementor-widget-image-box" data-id="7ac53e1" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img loading="lazy" decoding="async" width="300" height="300" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/icon-5-1.png" class="elementor-animation-grow attachment-full size-full wp-image-1352" alt=""  sizes="(max-width: 300px) 100vw, 300px" /></figure><div class="elementor-image-box-content"><h5 class="elementor-image-box-title">BCA</h5><p class="elementor-image-box-description">The Bachelor of Computer Applications program is tailored for students interested in computer science and information technology, offering in-depth knowledge of programming, software development, and computer systems.</p></div></div>		</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-832380f e-flex e-con-boxed e-con e-child" data-id="832380f" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-8391b92 elementor-position-top elementor-widget elementor-widget-image-box" data-id="8391b92" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-widget-image-box .elementor-image-box-content{width:100%}@media (min-width:768px){.elementor-widget-image-box.elementor-position-left .elementor-image-box-wrapper,.elementor-widget-image-box.elementor-position-right .elementor-image-box-wrapper{display:flex}.elementor-widget-image-box.elementor-position-right .elementor-image-box-wrapper{text-align:end;flex-direction:row-reverse}.elementor-widget-image-box.elementor-position-left .elementor-image-box-wrapper{text-align:start;flex-direction:row}.elementor-widget-image-box.elementor-position-top .elementor-image-box-img{margin:auto}.elementor-widget-image-box.elementor-vertical-align-top .elementor-image-box-wrapper{align-items:flex-start}.elementor-widget-image-box.elementor-vertical-align-middle .elementor-image-box-wrapper{align-items:center}.elementor-widget-image-box.elementor-vertical-align-bottom .elementor-image-box-wrapper{align-items:flex-end}}@media (max-width:767px){.elementor-widget-image-box .elementor-image-box-img{margin-left:auto!important;margin-right:auto!important;margin-bottom:15px}}.elementor-widget-image-box .elementor-image-box-img{display:inline-block}.elementor-widget-image-box .elementor-image-box-title a{color:inherit}.elementor-widget-image-box .elementor-image-box-wrapper{text-align:center}.elementor-widget-image-box .elementor-image-box-description{margin:0}</style><div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img loading="lazy" decoding="async" width="300" height="300" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/icon-4-1.png" class="elementor-animation-grow attachment-full size-full wp-image-1353" alt=""  sizes="(max-width: 300px) 100vw, 300px" /></figure><div class="elementor-image-box-content"><h5 class="elementor-image-box-title">BBA</h5><p class="elementor-image-box-description">The Bachelor of Business Administration program is designed for aspiring business professionals, covering essential topics in management, marketing, finance, and entrepreneurship.</p></div></div>		</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-318e63b e-flex e-con-boxed e-con e-child" data-id="318e63b" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-a1a5972 elementor-position-top elementor-widget elementor-widget-image-box" data-id="a1a5972" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img loading="lazy" decoding="async" width="300" height="300" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/icon-7.png" class="elementor-animation-grow attachment-full size-full wp-image-1432" alt=""  sizes="(max-width: 300px) 100vw, 300px" /></figure><div class="elementor-image-box-content"><h5 class="elementor-image-box-title">MTech</h5><p class="elementor-image-box-description">The Master of Technology program offers advanced knowledge in engineering and technology, focusing on research and development to prepare students for high-level technical roles.</p></div></div>		</div>
				</div>
					</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-5423a35 e-flex e-con-boxed elementor-invisible e-con e-child" data-id="5423a35" data-element_type="container" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-9b460d8 e-flex e-con-boxed e-con e-child" data-id="9b460d8" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-b410a6c elementor-position-top elementor-widget elementor-widget-image-box" data-id="b410a6c" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img loading="lazy" decoding="async" width="300" height="300" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/icon-3-1.png" class="elementor-animation-grow attachment-full size-full wp-image-1350" alt=""  sizes="(max-width: 300px) 100vw, 300px" /></figure><div class="elementor-image-box-content"><h5 class="elementor-image-box-title">MBA</h5><p class="elementor-image-box-description">Our Master of Business Administration program focuses on developing leadership and management skills, with a curriculum designed to address contemporary business challenges and opportunities.</p></div></div>		</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-832380f e-flex e-con-boxed e-con e-child" data-id="832380f" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-8391b92 elementor-position-top elementor-widget elementor-widget-image-box" data-id="8391b92" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-widget-image-box .elementor-image-box-content{width:100%}@media (min-width:768px){.elementor-widget-image-box.elementor-position-left .elementor-image-box-wrapper,.elementor-widget-image-box.elementor-position-right .elementor-image-box-wrapper{display:flex}.elementor-widget-image-box.elementor-position-right .elementor-image-box-wrapper{text-align:end;flex-direction:row-reverse}.elementor-widget-image-box.elementor-position-left .elementor-image-box-wrapper{text-align:start;flex-direction:row}.elementor-widget-image-box.elementor-position-top .elementor-image-box-img{margin:auto}.elementor-widget-image-box.elementor-vertical-align-top .elementor-image-box-wrapper{align-items:flex-start}.elementor-widget-image-box.elementor-vertical-align-middle .elementor-image-box-wrapper{align-items:center}.elementor-widget-image-box.elementor-vertical-align-bottom .elementor-image-box-wrapper{align-items:flex-end}}@media (max-width:767px){.elementor-widget-image-box .elementor-image-box-img{margin-left:auto!important;margin-right:auto!important;margin-bottom:15px}}.elementor-widget-image-box .elementor-image-box-img{display:inline-block}.elementor-widget-image-box .elementor-image-box-title a{color:inherit}.elementor-widget-image-box .elementor-image-box-wrapper{text-align:center}.elementor-widget-image-box .elementor-image-box-description{margin:0}</style><div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img loading="lazy" decoding="async" width="300" height="300" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/icon-1-1.png" class="elementor-animation-grow attachment-full size-full wp-image-1353" alt=""  sizes="(max-width: 300px) 100vw, 300px" /></figure><div class="elementor-image-box-content"><h5 class="elementor-image-box-title">Diploma</h5><p class="elementor-image-box-description">We offer diploma programs in various technical and non-technical fields, providing practical skills and industry-relevant knowledge to enhance employability.</p></div></div>		</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-6213122 e-flex e-con-boxed e-con e-child" data-id="6213122" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-d48d3d5 elementor-position-top elementor-widget elementor-widget-image-box" data-id="d48d3d5" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img loading="lazy" decoding="async" width="300" height="300" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/icon-2.png" class="elementor-animation-grow attachment-full size-full wp-image-1349" alt=""  sizes="(max-width: 300px) 100vw, 300px" /></figure><div class="elementor-image-box-content"><h5 class="elementor-image-box-title">BHM</h5><p class="elementor-image-box-description">Our Bachelor of Hotel Management program equips students with the skills needed for a career in the hospitality industry, covering areas such as hotel operations, food and beverage management, and customer service.</p></div></div>		</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-832380f e-flex e-con-boxed e-con e-child" data-id="832380f" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-8391b92 elementor-position-top elementor-widget elementor-widget-image-box" data-id="8391b92" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-widget-image-box .elementor-image-box-content{width:100%}@media (min-width:768px){.elementor-widget-image-box.elementor-position-left .elementor-image-box-wrapper,.elementor-widget-image-box.elementor-position-right .elementor-image-box-wrapper{display:flex}.elementor-widget-image-box.elementor-position-right .elementor-image-box-wrapper{text-align:end;flex-direction:row-reverse}.elementor-widget-image-box.elementor-position-left .elementor-image-box-wrapper{text-align:start;flex-direction:row}.elementor-widget-image-box.elementor-position-top .elementor-image-box-img{margin:auto}.elementor-widget-image-box.elementor-vertical-align-top .elementor-image-box-wrapper{align-items:flex-start}.elementor-widget-image-box.elementor-vertical-align-middle .elementor-image-box-wrapper{align-items:center}.elementor-widget-image-box.elementor-vertical-align-bottom .elementor-image-box-wrapper{align-items:flex-end}}@media (max-width:767px){.elementor-widget-image-box .elementor-image-box-img{margin-left:auto!important;margin-right:auto!important;margin-bottom:15px}}.elementor-widget-image-box .elementor-image-box-img{display:inline-block}.elementor-widget-image-box .elementor-image-box-title a{color:inherit}.elementor-widget-image-box .elementor-image-box-wrapper{text-align:center}.elementor-widget-image-box .elementor-image-box-description{margin:0}</style><div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img loading="lazy" decoding="async" width="300" height="300" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/icon-8.png" class="elementor-animation-grow attachment-full size-full wp-image-1353" alt=""  sizes="(max-width: 300px) 100vw, 300px" /></figure><div class="elementor-image-box-content"><h5 class="elementor-image-box-title">MCA</h5><p class="elementor-image-box-description">The Master of Computer Applications program provides advanced education in computer science, with a focus on software development, systems management, and data analysis.</p></div></div>		</div>
				</div>
					</div>
				</div>
					</div>
				</div>
					</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-e2b7580 e-flex e-con-boxed e-con e-child" data-id="e2b7580" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-fa2fdd5 e-flex e-con-boxed e-con e-child" data-id="fa2fdd5" data-element_type="container">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-e6c42a1 elementor-widget elementor-widget-qi_addons_for_elementor_counter" data-id="0faacaa" data-element_type="widget" data-widget_type="qi_addons_for_elementor_counter.default">
				<div class="elementor-widget-container">
			<div class="qodef-shortcode qodef-m  qodef-qi-counter qodef-layout--simple  " data-end-digit="12">
	<div class="qodef-m-digit-wrapper">
		<div class="qodef-m-digit"></div>
	</div>
		<div class="qodef-m-content">
			<p class="qodef-m-title">
		Awards	</p>
			</div>
</div>
		</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-4505ff0 e-flex e-con-boxed e-con e-child" data-id="4505ff0" data-element_type="container">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-e6c42a1 elementor-widget elementor-widget-qi_addons_for_elementor_counter" data-id="e6c42a1" data-element_type="widget" data-widget_type="qi_addons_for_elementor_counter.default">
				<div class="elementor-widget-container">
			<div class="qodef-shortcode qodef-m  qodef-qi-counter qodef-layout--simple  " data-end-digit="16" data-digit-label="+">
	<div class="qodef-m-digit-wrapper">
		<div class="qodef-m-digit"></div>
	</div>
		<div class="qodef-m-content">
			<p class="qodef-m-title">
		Great Faculties	</p>
			</div>
</div>
		</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-1d2b5e1 e-flex e-con-boxed e-con e-child" data-id="1d2b5e1" data-element_type="container">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-322d502 elementor-widget elementor-widget-qi_addons_for_elementor_counter" data-id="322d502" data-element_type="widget" data-widget_type="qi_addons_for_elementor_counter.default">
				<div class="elementor-widget-container">
			<div class="qodef-shortcode qodef-m  qodef-qi-counter qodef-layout--simple  " data-end-digit="3.2" data-digit-label="K">
	<div class="qodef-m-digit-wrapper">
		<div class="qodef-m-digit"></div>
	</div>
		<div class="qodef-m-content">
			<p class="qodef-m-title">
		Member School	</p>
			</div>
</div>
		</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-23ad0b0 e-flex e-con-boxed e-con e-child" data-id="23ad0b0" data-element_type="container">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-d7dbcf9 elementor-widget elementor-widget-qi_addons_for_elementor_counter" data-id="d7dbcf9" data-element_type="widget" data-widget_type="qi_addons_for_elementor_counter.default">
				<div class="elementor-widget-container">
			<div class="qodef-shortcode qodef-m  qodef-qi-counter qodef-layout--simple  " data-end-digit="10" data-digit-label="+">
	<div class="qodef-m-digit-wrapper">
		<div class="qodef-m-digit"></div>
	</div>
		<div class="qodef-m-content">
			<p class="qodef-m-title">
		Working Years	</p>
			</div>
</div>
		</div>
				</div>
					</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-1bed589 e-flex e-con-boxed e-con e-parent" data-id="1bed589" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-cff6583 e-flex e-con-boxed e-con e-child" data-id="cff6583" data-element_type="container">
					<div class="e-con-inner">
						<div class="elementor-element elementor-element-2111151 elementor-widget elementor-widget-heading" data-id="2111151" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container" style="text-align: center;">
<h6 class="elementor-heading-title elementor-size-default">Notice for Student</h6>		</div>
</div>

<div class="elementor-element elementor-element-969c4c8 elementor-widget elementor-widget-heading" data-id="969c4c8" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container" style="text-align: center;">
<h2 class="elementor-heading-title elementor-size-default" style="color:#fff;">Notice Board</h2>		</div>
</div>
				<!-- for Scrolling Notice Board-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>
$(function () {
  var tickerLength = $(".container ul li").length;
  var tickerHeight = $(".container ul li").outerHeight();
  $(".container ul li:last-child").prependTo(".container ul");
  $(".container ul").css("marginTop", -tickerHeight);
  function moveTop() {
    $(".container ul").animate(
      {
        top: -tickerHeight
      },
      600,
      function () {
        $(".container ul li:first-child").appendTo(".container ul");
        $(".container ul").css("top", "");
      }
    );
  }
  setInterval(function () {
    moveTop();
  }, 3000);
});


</script>
<style>
.container {
  width: 100%;
  height: 650px;
  overflow: hidden;
  padding-top:-50px;
}
ul.notice {
  list-style: none;
  position: relative;
}
li.notice {
  height: 80px;
  background-color: rgba(153, 11, 11,0.9);
  text-align: center;
  border-bottom: 1px solid #333;
}
h2.notice {
  color: #fff;
  padding-top: 10px;
  font-size:15px;
}
p.notice {
  text-align: left;
  padding: 10px;
  color: #eee;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

</style>
<div class="container">
  <ul class="notice">
    <li class="notice">
      <h2 class="notice">Head line 1</h2>
      <p class="notice">News detail just a line jhghdsbd hsdssdhjhdjshdjsahdjs</p>
    </li>
    <li class="notice">
      <h2 class="notice">Head line 2</h2>
      <p class="notice">News detail just a line jhghdsbd hsdssdhjhdjshdjsahdjs</p>
    </li>
    <li class="notice">
      <h2 class="notice">Head line 3</h2>
      <p class="notice">News detail just a line jhghdsbd hsdssdhjhdjshdjsahdjs</p>
    </li>
    <li class="notice">
      <h2 class="notice">Head line 4</h2>
      <p class="notice">News detail just a line jhghdsbd hsdssdhjhdjshdjsahdjs</p>
    </li>
    <li class="notice">
      <h2 class="notice">Head line 5</h2>
      <p class="notice">News detail just a line jhghdsbd hsdssdhjhdjshdjsahdjs</p>
    </li>
    <li class="notice">
      <h2 class="notice">Head line 6</h2>
      <p class="notice">News detail just a line jhghdsbd hsdssdhjhdjshdjsahdjs</p>
    </li>
    <li class="notice">
      <h2 class="notice">Head line 7</h2>
      <p class="notice">News detail just a line jhghdsbd hsdssdhjhdjshdjsahdjs</p>
    </li>
    <li class="notice">
      <h2 class="notice">Head line 8</h2>
      <p class="notice">News detail just a line jhghdsbd hsdssdhjhdjshdjsahdjs</p>
    </li>

  </ul>
</div>
<div class="elementor-element elementor-element-827a504 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="827a504" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
<!--Notice Board End-->
					</div>
				</div>
		<div class="elementor-element elementor-element-33d95f3 e-con-full e-flex e-con e-child" data-id="33d95f3" data-element_type="container">
		<div class="elementor-element elementor-element-e041316 e-flex e-con-boxed e-con e-child" data-id="e041316" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-cf3a0d7 e-flex e-con-boxed e-con e-child" data-id="cf3a0d7" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-36a412e e-flex e-con-boxed e-con e-child" data-id="36a412e" data-element_type="container">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-26daff0 elementor-widget elementor-widget-spacer" data-id="26daff0" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-40c38c9 elementor-invisible elementor-widget elementor-widget-image" data-id="40c38c9" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img loading="lazy" decoding="async" width="611" height="941" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/photo-7.jpg" class="attachment-full size-full wp-image-774" alt=""  sizes="(max-width: 611px) 100vw, 611px" />													</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-918ff46 e-con-full e-flex e-con e-child" data-id="918ff46" data-element_type="container">
				<div class="elementor-element elementor-element-a226de7 elementor-invisible elementor-widget elementor-widget-image" data-id="a226de7" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInDown&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img loading="lazy" decoding="async" width="620" height="620" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/photo-9-2.png" class="attachment-full size-full wp-image-973" alt=""  sizes="(max-width: 620px) 100vw, 620px" />													</div>
				</div>
				<div class="elementor-element elementor-element-4c1b06f elementor-invisible elementor-widget elementor-widget-image" data-id="4c1b06f" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">

													<img loading="lazy" decoding="async" width="1920" height="1280" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/photo-8.jpg" class="attachment-full size-full wp-image-799" alt="" sizes="(max-width: 1920px) 100vw, 1920px" />													</div>
				</div>
				</div>
					</div>
				</div>
					</div>
				</div>
				</div>
					</div>
				</div>
		<!--<div class="elementor-element elementor-element-10d9cd4 e-flex e-con-boxed e-con e-parent" data-id="10d9cd4" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;gradient&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-8221da7 e-flex e-con-boxed e-con e-child" data-id="8221da7" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-d32615e e-flex e-con-boxed elementor-invisible e-con e-child" data-id="d32615e" data-element_type="container" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-97b4f6c elementor-widget elementor-widget-video" data-id="97b4f6c" data-element_type="widget" data-settings="{&quot;youtube_url&quot;:&quot;https:\/\/www.youtube.com\/watch?v=XHOmBV4js_E&quot;,&quot;show_image_overlay&quot;:&quot;yes&quot;,&quot;image_overlay&quot;:{&quot;url&quot;:&quot;http:\/\/hrkit.rometheme.pro\/zevone\/wp-content\/uploads\/sites\/89\/2023\/10\/blog-1.jpg&quot;,&quot;id&quot;:1238,&quot;size&quot;:&quot;&quot;,&quot;alt&quot;:&quot;&quot;,&quot;source&quot;:&quot;library&quot;},&quot;video_type&quot;:&quot;youtube&quot;,&quot;controls&quot;:&quot;yes&quot;}" data-widget_type="video.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-widget-video .elementor-widget-container{overflow:hidden;transform:translateZ(0)}.elementor-widget-video .elementor-wrapper{aspect-ratio:var(--video-aspect-ratio)}.elementor-widget-video .elementor-wrapper iframe,.elementor-widget-video .elementor-wrapper video{height:100%;width:100%;display:flex;border:none;background-color:#000}@supports not (aspect-ratio:1/1){.elementor-widget-video .elementor-wrapper{position:relative;overflow:hidden;height:0;padding-bottom:calc(100% / var(--video-aspect-ratio))}.elementor-widget-video .elementor-wrapper iframe,.elementor-widget-video .elementor-wrapper video{position:absolute;top:0;right:0;bottom:0;left:0}}.elementor-widget-video .elementor-open-inline .elementor-custom-embed-image-overlay{position:absolute;top:0;right:0;bottom:0;left:0;background-size:cover;background-position:50%}.elementor-widget-video .elementor-custom-embed-image-overlay{cursor:pointer;text-align:center}.elementor-widget-video .elementor-custom-embed-image-overlay:hover .elementor-custom-embed-play i{opacity:1}.elementor-widget-video .elementor-custom-embed-image-overlay img{display:block;width:100%;aspect-ratio:var(--video-aspect-ratio);-o-object-fit:cover;object-fit:cover;-o-object-position:center center;object-position:center center}@supports not (aspect-ratio:1/1){.elementor-widget-video .elementor-custom-embed-image-overlay{position:relative;overflow:hidden;height:0;padding-bottom:calc(100% / var(--video-aspect-ratio))}.elementor-widget-video .elementor-custom-embed-image-overlay img{position:absolute;top:0;right:0;bottom:0;left:0}}.elementor-widget-video .e-hosted-video .elementor-video{-o-object-fit:cover;object-fit:cover}.e-con-inner>.elementor-widget-video,.e-con>.elementor-widget-video{width:var(--container-widget-width);--flex-grow:var(--container-widget-flex-grow)}</style>		<div class="elementor-wrapper elementor-open-inline">
			<div class="elementor-video"></div>				<div class="elementor-custom-embed-image-overlay" style="background-image: url(<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/blog-1.jpg);">
																<div class="elementor-custom-embed-play" role="button" aria-label="Play Video" tabindex="0">
							<i aria-hidden="true" class="eicon-play"></i>							<span class="elementor-screen-only">Play Video</span>
						</div>
									</div>
					</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-a7e2755 elementor-widget elementor-widget-spacer" data-id="a7e2755" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-bada512 elementor-widget elementor-widget-heading" data-id="bada512" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">OUR MEDIA</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-f2b3df1 elementor-widget elementor-widget-heading" data-id="f2b3df1" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">See what our students can do</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-c054bcf elementor-widget elementor-widget-text-editor" data-id="c054bcf" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p> Nisl nisi scelerisque eu ultrices vitae auctor eu augue. Id neque aliquam vestibulum morbi blandit cursus risus. Enim ut sem viverra aliquet eget sit amet tellus.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-c7b430f elementor-widget elementor-widget-rtm-social_share" data-id="c7b430f" data-element_type="widget" data-widget_type="rtm-social_share.default">
				<div class="elementor-widget-container">
			        <div class="rkit-social-share">
            <dl class="rkit-social-media__list">                    <dt class="elementor-repeater-item-4eeb997">
                                                        <a type="button" data-social-media="facebook" class="rkit-social-share__link">
                                    <i aria-hidden="true" class="rkit-social-share__icon fab fa-facebook-f"></i>                                    Facebook                                </a>
                                            </dt>
                                <dt class="elementor-repeater-item-4603b6c">
                                                        <a type="button" data-social-media="twitter" class="rkit-social-share__link">
                                    <i aria-hidden="true" class="rkit-social-share__icon fab fa-twitter"></i>                                    Twitter                                </a>
                                            </dt>
                                <dt class="elementor-repeater-item-b4dbbd1">
                                                        <a type="button" data-social-media="whatsapp" class="rkit-social-share__link">
                                    <i aria-hidden="true" class="rkit-social-share__icon fab fa-whatsapp"></i>                                    Whatsapp                                </a>
                                            </dt>
                                <dt class="elementor-repeater-item-d85feb9">
                                                        <a type="button" data-social-media="telegram" class="rkit-social-share__link">
                                    <i aria-hidden="true" class="rkit-social-share__icon fab fa-telegram-plane"></i>                                    Telegram                                </a>
                                            </dt>
            </dl>        </div>
		</div>
				</div>
					</div>
				</div>
					</div>
				</div>
					</div>
				</div>-->
		<div class="elementor-element elementor-element-43edc3d e-flex e-con-boxed e-con e-parent" data-id="43edc3d" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-17a4b0f e-flex e-con-boxed e-con e-child" data-id="17a4b0f" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-ba476f7 e-con-full e-flex elementor-invisible e-con e-child" data-id="ba476f7" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;gradient&quot;,&quot;animation&quot;:&quot;fadeInDown&quot;}">
				<div class="elementor-element elementor-element-20a7d1d elementor-widget elementor-widget-image" data-id="20a7d1d" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img loading="lazy" decoding="async" width="597" height="1132" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/photo-2-2.png" class="attachment-full size-full wp-image-732" alt=""  sizes="(max-width: 597px) 100vw, 597px" />													</div>
				</div>
				</div>
		<div class="elementor-element elementor-element-27c2274 e-flex e-con-boxed e-con e-child" data-id="27c2274" data-element_type="container">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-ee49f8a elementor-widget elementor-widget-spacer" data-id="ee49f8a" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-eb89815 elementor-invisible elementor-widget elementor-widget-image" data-id="eb89815" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img loading="lazy" decoding="async" width="611" height="941" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/photo-9.jpg" class="attachment-full size-full wp-image-846" alt=""  sizes="(max-width: 611px) 100vw, 611px" />													</div>
				</div>
					</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-708101e e-con-full e-flex e-con e-child" data-id="708101e" data-element_type="container">
				<div class="elementor-element elementor-element-b78da34 elementor-widget elementor-widget-heading" data-id="b78da34" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">OUR FACILITIES</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-5709a84 elementor-widget elementor-widget-heading" data-id="5709a84" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default" style="color:#fff;">Top Facilities at Nexus Institute of Technology</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-420c9bc elementor-widget elementor-widget-text-editor" data-id="420c9bc" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>At Nexus Institute of Technology, we pride ourselves on providing top-notch facilities that enhance the educational experience and foster professional growth. Here are three key features that set our college apart</p>						</div>
				</div>
		<div class="elementor-element elementor-element-43a863a e-flex e-con-boxed e-con e-child" data-id="43a863a" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-1727f1e e-con-full e-flex e-con e-child" data-id="1727f1e" data-element_type="container">
				<div class="elementor-element elementor-element-0eb3a62 elementor-widget elementor-widget-heading" data-id="0eb3a62" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default">01</p>		</div>
				</div>
				</div>
		<div class="elementor-element elementor-element-6497485 e-con-full e-flex e-con e-child" data-id="6497485" data-element_type="container">
				<div class="elementor-element elementor-element-383f78c elementor-widget elementor-widget-heading" data-id="383f78c" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h5 class="elementor-heading-title elementor-size-default" style="color:#fff;">Advanced Tech Laboratories</h5>		</div>
				</div>
				<div class="elementor-element elementor-element-24f0cd5 elementor-widget elementor-widget-text-editor" data-id="24f0cd5" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Our state-of-the-art engineering labs are equipped with cutting-edge technology, providing students with hands-on experience in their respective fields and opportunities for innovative research and practical application.</p>						</div>
				</div>
				</div>
					</div>
				</div>
				<div class="elementor-element elementor-element-99cb0fe elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="99cb0fe" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-widget-divider{--divider-border-style:none;--divider-border-width:1px;--divider-color:#0c0d0e;--divider-icon-size:20px;--divider-element-spacing:10px;--divider-pattern-height:24px;--divider-pattern-size:20px;--divider-pattern-url:none;--divider-pattern-repeat:repeat-x}.elementor-widget-divider .elementor-divider{display:flex}.elementor-widget-divider .elementor-divider__text{font-size:15px;line-height:1;max-width:95%}.elementor-widget-divider .elementor-divider__element{margin:0 var(--divider-element-spacing);flex-shrink:0}.elementor-widget-divider .elementor-icon{font-size:var(--divider-icon-size)}.elementor-widget-divider .elementor-divider-separator{display:flex;margin:0;direction:ltr}.elementor-widget-divider--view-line_icon .elementor-divider-separator,.elementor-widget-divider--view-line_text .elementor-divider-separator{align-items:center}.elementor-widget-divider--view-line_icon .elementor-divider-separator:after,.elementor-widget-divider--view-line_icon .elementor-divider-separator:before,.elementor-widget-divider--view-line_text .elementor-divider-separator:after,.elementor-widget-divider--view-line_text .elementor-divider-separator:before{display:block;content:"";border-block-end:0;flex-grow:1;border-block-start:var(--divider-border-width) var(--divider-border-style) var(--divider-color)}.elementor-widget-divider--element-align-left .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type{flex-grow:0;flex-shrink:100}.elementor-widget-divider--element-align-left .elementor-divider-separator:before{content:none}.elementor-widget-divider--element-align-left .elementor-divider__element{margin-left:0}.elementor-widget-divider--element-align-right .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type{flex-grow:0;flex-shrink:100}.elementor-widget-divider--element-align-right .elementor-divider-separator:after{content:none}.elementor-widget-divider--element-align-right .elementor-divider__element{margin-right:0}.elementor-widget-divider--element-align-start .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type{flex-grow:0;flex-shrink:100}.elementor-widget-divider--element-align-start .elementor-divider-separator:before{content:none}.elementor-widget-divider--element-align-start .elementor-divider__element{margin-inline-start:0}.elementor-widget-divider--element-align-end .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type{flex-grow:0;flex-shrink:100}.elementor-widget-divider--element-align-end .elementor-divider-separator:after{content:none}.elementor-widget-divider--element-align-end .elementor-divider__element{margin-inline-end:0}.elementor-widget-divider:not(.elementor-widget-divider--view-line_text):not(.elementor-widget-divider--view-line_icon) .elementor-divider-separator{border-block-start:var(--divider-border-width) var(--divider-border-style) var(--divider-color)}.elementor-widget-divider--separator-type-pattern{--divider-border-style:none}.elementor-widget-divider--separator-type-pattern.elementor-widget-divider--view-line .elementor-divider-separator,.elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:after,.elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:before,.elementor-widget-divider--separator-type-pattern:not([class*=elementor-widget-divider--view]) .elementor-divider-separator{width:100%;min-height:var(--divider-pattern-height);-webkit-mask-size:var(--divider-pattern-size) 100%;mask-size:var(--divider-pattern-size) 100%;-webkit-mask-repeat:var(--divider-pattern-repeat);mask-repeat:var(--divider-pattern-repeat);background-color:var(--divider-color);-webkit-mask-image:var(--divider-pattern-url);mask-image:var(--divider-pattern-url)}.elementor-widget-divider--no-spacing{--divider-pattern-size:auto}.elementor-widget-divider--bg-round{--divider-pattern-repeat:round}.rtl .elementor-widget-divider .elementor-divider__text{direction:rtl}.e-con-inner>.elementor-widget-divider,.e-con>.elementor-widget-divider{width:var(--container-widget-width,100%);--flex-grow:var(--container-widget-flex-grow)}</style>		<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
		<div class="elementor-element elementor-element-7c0b795 e-flex e-con-boxed e-con e-child" data-id="7c0b795" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-f0fbb68 e-con-full e-flex e-con e-child" data-id="f0fbb68" data-element_type="container">
				<div class="elementor-element elementor-element-e896a9e elementor-widget elementor-widget-heading" data-id="e896a9e" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default">02</p>		</div>
				</div>
				</div>
		<div class="elementor-element elementor-element-38abf51 e-con-full e-flex e-con e-child" data-id="38abf51" data-element_type="container">
				<div class="elementor-element elementor-element-3dc5e5c elementor-widget elementor-widget-heading" data-id="3dc5e5c" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h5 class="elementor-heading-title elementor-size-default" style="color:#fff;">Industry-Integrated Career Services</h5>		</div>
				</div>
				<div class="elementor-element elementor-element-fcd1fe9 elementor-widget elementor-widget-text-editor" data-id="fcd1fe9" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Our robust Training and Placement Cell offers comprehensive career support, including industry internships, job placement assistance, career counseling, and workshops to prepare students for successful engineering careers.</p>						</div>
				</div>
				</div>
					</div>
				</div>
				<div class="elementor-element elementor-element-e005511 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="e005511" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
		<div class="elementor-element elementor-element-1c7b53b e-flex e-con-boxed e-con e-child" data-id="1c7b53b" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-ed6a5ba e-con-full e-flex e-con e-child" data-id="ed6a5ba" data-element_type="container">
				<div class="elementor-element elementor-element-b29cbfc elementor-widget elementor-widget-heading" data-id="b29cbfc" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<p class="elementor-heading-title elementor-size-default">03</p>		</div>
				</div>
				</div>
		<div class="elementor-element elementor-element-0efe177 e-con-full e-flex e-con e-child" data-id="0efe177" data-element_type="container">
				<div class="elementor-element elementor-element-7a87c02 elementor-widget elementor-widget-heading" data-id="7a87c02" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h5 class="elementor-heading-title elementor-size-default" style="color:#fff;">High-Tech Campus Amenities</h5>		</div>
				</div>
				<div class="elementor-element elementor-element-ae5f245 elementor-widget elementor-widget-text-editor" data-id="ae5f245" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Our modern campus features high-speed internet, a well-equipped library, advanced computer labs, and excellent sports facilities, creating an environment that supports both academic and personal growth.</p>						</div>
				</div>
				</div>
					</div>
				</div>
				</div>
					</div>
				</div>
		
		<div class="elementor-element elementor-element-47b70a0 e-flex e-con-boxed e-con e-parent" data-id="47b70a0" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-9dfa033 e-flex e-con-boxed e-con e-child" data-id="9dfa033" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-3dd05e8 elementor-widget elementor-widget-heading" data-id="3dd05e8" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">OUR RECRUITERS</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-7d5a697 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="7d5a697" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-e75051c elementor-widget elementor-widget-image-carousel" data-id="e75051c" data-element_type="widget" data-settings="{&quot;slides_to_show&quot;:&quot;6&quot;,&quot;slides_to_scroll&quot;:&quot;1&quot;,&quot;navigation&quot;:&quot;none&quot;,&quot;autoplay_speed&quot;:8000,&quot;image_spacing_custom&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:50,&quot;sizes&quot;:[]},&quot;slides_to_show_tablet&quot;:&quot;5&quot;,&quot;slides_to_show_mobile&quot;:&quot;3&quot;,&quot;image_spacing_custom_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:30,&quot;sizes&quot;:[]},&quot;image_spacing_custom_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;autoplay&quot;:&quot;yes&quot;,&quot;pause_on_hover&quot;:&quot;yes&quot;,&quot;pause_on_interaction&quot;:&quot;yes&quot;,&quot;infinite&quot;:&quot;yes&quot;,&quot;speed&quot;:500}" data-widget_type="image-carousel.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-widget-image-carousel .swiper,.elementor-widget-image-carousel .swiper-container{position:static}.elementor-widget-image-carousel .swiper-container .swiper-slide figure,.elementor-widget-image-carousel .swiper .swiper-slide figure{line-height:inherit}.elementor-widget-image-carousel .swiper-slide{text-align:center}.elementor-image-carousel-wrapper:not(.swiper-container-initialized):not(.swiper-initialized) .swiper-slide{max-width:calc(100% / var(--e-image-carousel-slides-to-show, 3))}</style>		<div class="elementor-image-carousel-wrapper swiper" dir="ltr">
			<div class="elementor-image-carousel swiper-wrapper" aria-live="off">
								<div class="swiper-slide" role="group" aria-roledescription="slide" aria-label="1 of 7"><figure class="swiper-slide-inner">
									<img decoding="async" class="swiper-slide-image" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/logo-1-1.png" alt="logo-1" />
								</figure>
								</div>
								<div class="swiper-slide" role="group" aria-roledescription="slide" aria-label="2 of 7"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/logo-2-1.png" alt="logo-2" />
								</figure>
								</div>
								<div class="swiper-slide" role="group" aria-roledescription="slide" aria-label="3 of 7"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/logo-3-1.png" alt="logo-3" /></figure></div><div class="swiper-slide" role="group" aria-roledescription="slide" aria-label="4 of 7"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/logo-4-1.png" alt="logo-4" /></figure></div><div class="swiper-slide" role="group" aria-roledescription="slide" aria-label="5 of 7"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/logo-5-1.png" alt="logo-5" /></figure></div><div class="swiper-slide" role="group" aria-roledescription="slide" aria-label="6 of 7"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/logo-6.png" alt="logo-6" /></figure></div><div class="swiper-slide" role="group" aria-roledescription="slide" aria-label="7 of 7"><figure class="swiper-slide-inner"><img decoding="async" class="swiper-slide-image" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/logo-7.png" alt="logo-7" /></figure></div>			</div>
							
									</div>
				</div>
				</div>
					</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-a1d1155 e-flex e-con-boxed e-con e-parent" data-id="a1d1155" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-d5a0c4b e-flex e-con-boxed e-con e-child" data-id="d5a0c4b" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-e587af3 e-flex e-con-boxed e-con e-child" data-id="e587af3" data-element_type="container">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-7f10fdd elementor-widget elementor-widget-heading" data-id="7f10fdd" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">join now</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-359c73c elementor-widget elementor-widget-heading" data-id="359c73c" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Get a Free Lesson</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-3585497 elementor-widget elementor-widget-text-editor" data-id="3585497" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Nibh cras pulvinar mattis nunc. Proin sagittis nisl rhoncus mattis. Neque vitae tempus quam pellentesque nec nam aliquam sem et. Velit euismod in pellentesque massa placerat duis.</p>						</div>
				</div>
		<div class="elementor-element elementor-element-6324296 e-flex e-con-boxed e-con e-child" data-id="6324296" data-element_type="container">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-f5c4720 elementor-align-center elementor-widget elementor-widget-button" data-id="f5c4720" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-lg" href="#">
						<span class="elementor-button-content-wrapper">
									<span class="elementor-button-text">See Our Muisic Classes</span>
					</span>
					</a>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-e8ce56b elementor-view-framed elementor-position-left elementor-shape-circle elementor-mobile-position-top elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="e8ce56b" data-element_type="widget" data-widget_type="icon-box.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-box-wrapper">

						<div class="elementor-icon-box-icon">
				<span  class="elementor-icon elementor-animation-">
				<i aria-hidden="true" class="fas fa-phone-alt"></i>				</span>
			</div>
			
						<div class="elementor-icon-box-content">

									<p class="elementor-icon-box-title">
						<span  >
							FOR FURTHER INQUIRY						</span>
					</p>
				
									<p class="elementor-icon-box-description">
						(+123) - 1234 - 234 					</p>
				
			</div>
			
		</div>
				</div>
				</div>
					</div>
				</div>
					</div>
				</div>
					</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-dc2cac9 e-flex e-con-boxed e-con e-parent" data-id="dc2cac9" data-element_type="container">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-fe45690 elementor-widget elementor-widget-heading" data-id="fe45690" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">OUR TEAM</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-d867d1d elementor-widget elementor-widget-heading" data-id="d867d1d" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default" style="color:#fff;">Meet Our Team</h2>		</div>
				</div>
				<!--<div class="elementor-element elementor-element-a69bf23 elementor-widget elementor-widget-text-editor" data-id="a69bf23" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Ipsum dolor sit amet consectetur. Scelerisque fermentum dui faucibus in.</p>						</div>
				</div>-->
		<div class="elementor-element elementor-element-dea5a6c e-flex e-con-boxed elementor-invisible e-con e-child" data-id="dea5a6c" data-element_type="container" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-73c538b e-flex e-con-boxed e-con e-child" data-id="73c538b" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-fa88edd e-flex e-con-boxed e-con e-child" data-id="fa88edd" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-e331620 elementor-widget elementor-widget-qi_addons_for_elementor_team_member" data-id="e331620" data-element_type="widget" data-widget_type="qi_addons_for_elementor_team_member.default">
				<div class="elementor-widget-container">
			<div class="qodef-shortcode qodef-m  qodef-qi-team-member qodef-item-layout--info-on-hover-inset ">
	<div class="qodef-m-inner">
		<div class="qodef-m-image">
				<div class="qodef-m-media-image">
		<img loading="lazy" decoding="async" width="857" height="945" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/team-5.jpg" class="attachment-full size-full" alt=""  sizes="(max-width: 857px) 100vw, 857px" />	</div>
		</div>
		<div class="qodef-m-content">
				<h5 itemprop="name" class="qodef-m-title">
		Dr. Emily Winslow	</h5>
					<p class="qodef-m-role">Dept. of CSE</p>
							<div class="qodef-m-social-icons">
						<span class="qodef-e-social-icon">
									</span>
					</div>
		</div>
	</div>
</div>
		</div>

				</div>
				<div class="elementor-element elementor-element-03b3b92 elementor-widget elementor-widget-heading" data-id="03b3b92" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">Dr. Emily Winslow</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-2374dc6 elementor-shape-rounded elementor-grid-0 e-grid-align-center elementor-widget elementor-widget-social-icons" data-id="2374dc6" data-element_type="widget" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-widget-social-icons.elementor-grid-0 .elementor-widget-container,.elementor-widget-social-icons.elementor-grid-mobile-0 .elementor-widget-container,.elementor-widget-social-icons.elementor-grid-tablet-0 .elementor-widget-container{line-height:1;font-size:0}.elementor-widget-social-icons:not(.elementor-grid-0):not(.elementor-grid-tablet-0):not(.elementor-grid-mobile-0) .elementor-grid{display:inline-grid}.elementor-widget-social-icons .elementor-grid{grid-column-gap:var(--grid-column-gap,5px);grid-row-gap:var(--grid-row-gap,5px);grid-template-columns:var(--grid-template-columns);justify-content:var(--justify-content,center);justify-items:var(--justify-content,center)}.elementor-icon.elementor-social-icon{font-size:var(--icon-size,25px);line-height:var(--icon-size,25px);width:calc(var(--icon-size, 25px) + 2 * var(--icon-padding, .5em));height:calc(var(--icon-size, 25px) + 2 * var(--icon-padding, .5em))}.elementor-social-icon{--e-social-icon-icon-color:#fff;display:inline-flex;background-color:#69727d;align-items:center;justify-content:center;text-align:center;cursor:pointer}.elementor-social-icon i{color:var(--e-social-icon-icon-color)}.elementor-social-icon svg{fill:var(--e-social-icon-icon-color)}.elementor-social-icon:last-child{margin:0}.elementor-social-icon:hover{opacity:.9;color:#fff}.elementor-social-icon-android{background-color:#a4c639}.elementor-social-icon-apple{background-color:#999}.elementor-social-icon-behance{background-color:#1769ff}.elementor-social-icon-bitbucket{background-color:#205081}.elementor-social-icon-codepen{background-color:#000}.elementor-social-icon-delicious{background-color:#39f}.elementor-social-icon-deviantart{background-color:#05cc47}.elementor-social-icon-digg{background-color:#005be2}.elementor-social-icon-dribbble{background-color:#ea4c89}.elementor-social-icon-elementor{background-color:#d30c5c}.elementor-social-icon-envelope{background-color:#ea4335}.elementor-social-icon-facebook,.elementor-social-icon-facebook-f{background-color:#3b5998}.elementor-social-icon-flickr{background-color:#0063dc}.elementor-social-icon-foursquare{background-color:#2d5be3}.elementor-social-icon-free-code-camp,.elementor-social-icon-freecodecamp{background-color:#006400}.elementor-social-icon-github{background-color:#333}.elementor-social-icon-gitlab{background-color:#e24329}.elementor-social-icon-globe{background-color:#69727d}.elementor-social-icon-google-plus,.elementor-social-icon-google-plus-g{background-color:#dd4b39}.elementor-social-icon-houzz{background-color:#7ac142}.elementor-social-icon-instagram{background-color:#262626}.elementor-social-icon-jsfiddle{background-color:#487aa2}.elementor-social-icon-link{background-color:#818a91}.elementor-social-icon-linkedin,.elementor-social-icon-linkedin-in{background-color:#0077b5}.elementor-social-icon-medium{background-color:#00ab6b}.elementor-social-icon-meetup{background-color:#ec1c40}.elementor-social-icon-mixcloud{background-color:#273a4b}.elementor-social-icon-odnoklassniki{background-color:#f4731c}.elementor-social-icon-pinterest{background-color:#bd081c}.elementor-social-icon-product-hunt{background-color:#da552f}.elementor-social-icon-reddit{background-color:#ff4500}.elementor-social-icon-rss{background-color:#f26522}.elementor-social-icon-shopping-cart{background-color:#4caf50}.elementor-social-icon-skype{background-color:#00aff0}.elementor-social-icon-slideshare{background-color:#0077b5}.elementor-social-icon-snapchat{background-color:#fffc00}.elementor-social-icon-soundcloud{background-color:#f80}.elementor-social-icon-spotify{background-color:#2ebd59}.elementor-social-icon-stack-overflow{background-color:#fe7a15}.elementor-social-icon-steam{background-color:#00adee}.elementor-social-icon-stumbleupon{background-color:#eb4924}.elementor-social-icon-telegram{background-color:#2ca5e0}.elementor-social-icon-threads{background-color:#000}.elementor-social-icon-thumb-tack{background-color:#1aa1d8}.elementor-social-icon-tripadvisor{background-color:#589442}.elementor-social-icon-tumblr{background-color:#35465c}.elementor-social-icon-twitch{background-color:#6441a5}.elementor-social-icon-twitter{background-color:#1da1f2}.elementor-social-icon-viber{background-color:#665cac}.elementor-social-icon-vimeo{background-color:#1ab7ea}.elementor-social-icon-vk{background-color:#45668e}.elementor-social-icon-weibo{background-color:#dd2430}.elementor-social-icon-weixin{background-color:#31a918}.elementor-social-icon-whatsapp{background-color:#25d366}.elementor-social-icon-wordpress{background-color:#21759b}.elementor-social-icon-x-twitter{background-color:#000}.elementor-social-icon-xing{background-color:#026466}.elementor-social-icon-yelp{background-color:#af0606}.elementor-social-icon-youtube{background-color:#cd201f}.elementor-social-icon-500px{background-color:#0099e5}.elementor-shape-rounded .elementor-icon.elementor-social-icon{border-radius:10%}.elementor-shape-circle .elementor-icon.elementor-social-icon{border-radius:50%}</style>		<!--<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-animation-shrink elementor-repeater-item-da86e9e" target="_blank">
						<span class="elementor-screen-only">Facebook</span>
						<i class="fab fa-facebook"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-animation-shrink elementor-repeater-item-ca308ff" target="_blank">
						<span class="elementor-screen-only">Twitter</span>
						<i class="fab fa-twitter"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-animation-shrink elementor-repeater-item-ec74ab1" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<i class="fab fa-instagram"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-youtube elementor-animation-shrink elementor-repeater-item-31bd035" target="_blank">
						<span class="elementor-screen-only">Youtube</span>
						<i class="fab fa-youtube"></i>					</a>
				</span>
					</div>-->
				</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-9283604 e-flex e-con-boxed e-con e-child" data-id="9283604" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-a49c425 elementor-widget elementor-widget-qi_addons_for_elementor_team_member" data-id="a49c425" data-element_type="widget" data-widget_type="qi_addons_for_elementor_team_member.default">
				<div class="elementor-widget-container">
			<div class="qodef-shortcode qodef-m  qodef-qi-team-member qodef-item-layout--info-on-hover-inset ">
	<div class="qodef-m-inner">
		<div class="qodef-m-image">
				<div class="qodef-m-media-image">
		<img loading="lazy" decoding="async" width="857" height="945" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/team-3.jpg" class="attachment-full size-full" alt="" sizes="(max-width: 857px) 100vw, 857px" />	</div>
		</div>
		<div class="qodef-m-content">
				<h5 itemprop="name" class="qodef-m-title">
		Dr. Jonathan Myers	</h5>
					<p class="qodef-m-role">Dept. Of M.E.</p>
							<div class="qodef-m-social-icons">
						<span class="qodef-e-social-icon">
									</span>
					</div>
		</div>
	</div>
</div>
		</div>
				</div>
				<div class="elementor-element elementor-element-354e01c elementor-widget elementor-widget-heading" data-id="354e01c" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">Dr. Jonathan Myers</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-cb69a46 elementor-shape-rounded elementor-grid-0 e-grid-align-center elementor-widget elementor-widget-social-icons" data-id="cb69a46" data-element_type="widget" data-widget_type="social-icons.default">
				<!--<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-animation-shrink elementor-repeater-item-da86e9e" target="_blank">
						<span class="elementor-screen-only">Facebook</span>
						<i class="fab fa-facebook"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-animation-shrink elementor-repeater-item-ca308ff" target="_blank">
						<span class="elementor-screen-only">Twitter</span>
						<i class="fab fa-twitter"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-animation-shrink elementor-repeater-item-ec74ab1" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<i class="fab fa-instagram"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-youtube elementor-animation-shrink elementor-repeater-item-31bd035" target="_blank">
						<span class="elementor-screen-only">Youtube</span>
						<i class="fab fa-youtube"></i>					</a>
				</span>
					</div>
				</div>-->
				</div>
					</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-3aabfd8 e-con-full e-flex e-con e-child" data-id="3aabfd8" data-element_type="container">
		<div class="elementor-element elementor-element-5d5272c e-flex e-con-boxed e-con e-child" data-id="5d5272c" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-5ebe16e elementor-widget elementor-widget-qi_addons_for_elementor_team_member" data-id="5ebe16e" data-element_type="widget" data-widget_type="qi_addons_for_elementor_team_member.default">
				<div class="elementor-widget-container">
			<div class="qodef-shortcode qodef-m  qodef-qi-team-member qodef-item-layout--info-on-hover-inset ">
	<div class="qodef-m-inner">
		<div class="qodef-m-image">
				<div class="qodef-m-media-image">
		<img loading="lazy" decoding="async" width="857" height="945" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/team-1.jpg" class="attachment-full size-full" alt=""  sizes="(max-width: 857px) 100vw, 857px" />	</div>
		</div>
		<div class="qodef-m-content">
				<h5 itemprop="name" class="qodef-m-title">
		Dr. Vincent Carter	</h5>
					<p class="qodef-m-role">Dept. of BS&HU</p>
							<div class="qodef-m-social-icons">
						<span class="qodef-e-social-icon">
									</span>
					</div>
		</div>
	</div>
</div>
		</div>
				</div>
				<div class="elementor-element elementor-element-5d454ae elementor-widget elementor-widget-heading" data-id="5d454ae" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">Dr. Vincent Carter</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-6cc4757 elementor-shape-rounded elementor-grid-0 e-grid-align-center elementor-widget elementor-widget-social-icons" data-id="6cc4757" data-element_type="widget" data-widget_type="social-icons.default">
				<!--<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-animation-shrink elementor-repeater-item-da86e9e" target="_blank">
						<span class="elementor-screen-only">Facebook</span>
						<i class="fab fa-facebook"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-animation-shrink elementor-repeater-item-ca308ff" target="_blank">
						<span class="elementor-screen-only">Twitter</span>
						<i class="fab fa-twitter"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-animation-shrink elementor-repeater-item-ec74ab1" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<i class="fab fa-instagram"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-youtube elementor-animation-shrink elementor-repeater-item-31bd035" target="_blank">
						<span class="elementor-screen-only">Youtube</span>
						<i class="fab fa-youtube"></i>					</a>
				</span>
					</div>
				</div>-->
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-60098e0 e-flex e-con-boxed e-con e-child" data-id="60098e0" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-32940bc elementor-widget elementor-widget-qi_addons_for_elementor_team_member" data-id="32940bc" data-element_type="widget" data-widget_type="qi_addons_for_elementor_team_member.default">
				<div class="elementor-widget-container">
			<div class="qodef-shortcode qodef-m  qodef-qi-team-member qodef-item-layout--info-on-hover-inset ">
	<div class="qodef-m-inner">
		<div class="qodef-m-image">
				<div class="qodef-m-media-image">
		<img loading="lazy" decoding="async" width="857" height="945" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/team-2.jpg" class="attachment-full size-full" alt=""  sizes="(max-width: 857px) 100vw, 857px" />	</div>
		</div>
		<div class="qodef-m-content">
				<h5 itemprop="name" class="qodef-m-title">
		Dr. Sophia Turner	</h5>
					<p class="qodef-m-role">Dept. of BBA</p>
							<div class="qodef-m-social-icons">
						<span class="qodef-e-social-icon">
									</span>
					</div>
		</div>
	</div>
</div>
		</div>
				</div>
				<div class="elementor-element elementor-element-dbebe76 elementor-widget elementor-widget-heading" data-id="dbebe76" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">Dr. Sophia Turner</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-82b7122 elementor-shape-rounded elementor-grid-0 e-grid-align-center elementor-widget elementor-widget-social-icons" data-id="82b7122" data-element_type="widget" data-widget_type="social-icons.default">
				<!--<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-animation-shrink elementor-repeater-item-da86e9e" target="_blank">
						<span class="elementor-screen-only">Facebook</span>
						<i class="fab fa-facebook"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-animation-shrink elementor-repeater-item-ca308ff" target="_blank">
						<span class="elementor-screen-only">Twitter</span>
						<i class="fab fa-twitter"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-animation-shrink elementor-repeater-item-ec74ab1" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<i class="fab fa-instagram"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-youtube elementor-animation-shrink elementor-repeater-item-31bd035" target="_blank">
						<span class="elementor-screen-only">Youtube</span>
						<i class="fab fa-youtube"></i>					</a>
				</span>
					</div>
				</div>
				</div>-->
					</div>
				</div>
				</div>
					</div>
				</div>
				<div class="elementor-element elementor-element-f2e43d2 elementor-align-center elementor-widget elementor-widget-button" data-id="f2e43d2" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-lg" href="#">
						<span class="elementor-button-content-wrapper">
									<span class="elementor-button-text">Our Team</span>
					</span>
					</a>
		</div>
				</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-00c8180 e-flex e-con-boxed e-con e-parent" data-id="00c8180" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<!--<div class="elementor-element elementor-element-839dc07 elementor-widget elementor-widget-heading" data-id="839dc07" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">Multiple Offers</h6>		</div>
				</div>-->
				<div class="elementor-element elementor-element-867a555 elementor-widget elementor-widget-heading" data-id="867a555" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default" style="color:#fff;">Celebrating Success: Multiple Job Offers</h2>		</div>
				</div>
				<!--<div class="elementor-element elementor-element-bbd0905 elementor-widget elementor-widget-text-editor" data-id="bbd0905" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Nam libero justo laoreet sit amet cursus sit amet. Nec tincidunt praesent semper feugiat nibh sed pulvinar proin. Quam nulla porttitor massa id neque aliquam vestibulum morbi.</p>						</div>
				</div>-->
				<div class="elementor-element elementor-element-01074c7 elementor-invisible elementor-widget elementor-widget-rkit-blog-post" data-id="01074c7" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;}" data-widget_type="rkit-blog-post.default">
				<div class="elementor-widget-container">

			        <div class=" row">
			        	
						<div class="col-md-3">
							 <div class="rkit-blog-card">
							 <div class="rkit-image-container">
                                                        <a class="rkit-image-link" style="overflow: hidden;" href="2023/10/30/a-learning-community-network-for-beginners/index.html">
                                <img decoding="async" class="rkit-blog-img" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/blog-3.1.jpg">
                            </a>
                                                            <!--<div class="rkit-float-metawrapper-date">
                                    <span><strong>30</strong>Oct</span>
                                </div>-->
                                                    </div>
                                        <div class="rkit-blog-body ">
                                                    <div class="rkit-metadata">
                                                            </div>
                                                                            <div class="rkit-blog-title-container">
                                <a class="rkit-blog-title" href="2023/10/30/a-learning-community-network-for-beginners/index.html">Aniket Pramanik</a>
                            </div>
                                                                                                    <div class="rkit-blog-content">
                                <p class="rkit-blog-paragraph"> Aniket - "Securing multiple offers was a testament to the excellent training and support I received at Nexus Institute of Technology."&hellip;                                </p>
                            </div>
                                                                                                    <div class="rkit-readmore-div">
                                <a class="rkit-readmore-btn" type="button" href="2023/10/30/a-learning-community-network-for-beginners/index.html">
                                                                        Read More                                                                    </a>
                            </div>
                                            </div>

						</div>
					</div>
						<div class="col-md-3">
							<div class="rkit-image-container">
                                                        <a class="rkit-image-link" style="overflow: hidden;" href="2023/10/30/a-learning-community-network-for-beginners/index.html">
                                <img decoding="async" class="rkit-blog-img" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/blog-3.2.jpg">
                            </a>
                                                            <!--<div class="rkit-float-metawrapper-date">
                                    <span><strong>30</strong>Oct</span>
                                </div>-->
                                                    </div>
                                        <div class="rkit-blog-body ">
                                                    <div class="rkit-metadata">
                                                            </div>
                                                                            <div class="rkit-blog-title-container">
                                <a class="rkit-blog-title" href="2023/10/30/a-learning-community-network-for-beginners/index.html">Rajib Ghosh</a>
                            </div>
                                                                                                    <div class="rkit-blog-content">
                                <p class="rkit-blog-paragraph"> Rajib Ghosh: "The rigorous curriculum and career guidance at NiT helped me stand out to top MNCs."&hellip;                                </p>
                            </div>
                                                                                                    <div class="rkit-readmore-div">
                                <a class="rkit-readmore-btn" type="button" href="2023/10/30/a-learning-community-network-for-beginners/index.html">
                                                                        Read More                                                                    </a>
                            </div>
                                            </div>
						</div>
						<div class="col-md-3">
							<div class="rkit-image-container">
                                                        <a class="rkit-image-link" style="overflow: hidden;" href="2023/10/30/a-learning-community-network-for-beginners/index.html">
                                <img decoding="async" class="rkit-blog-img" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/blog-3.3.jpg">
                            </a>
                                                            <!--<div class="rkit-float-metawrapper-date">
                                    <span><strong>30</strong>Oct</span>
                                </div>-->
                                                    </div>
                                        <div class="rkit-blog-body ">
                                                    <div class="rkit-metadata">
                                                            </div>
                                                                            <div class="rkit-blog-title-container">
                                <a class="rkit-blog-title" href="2023/10/30/a-learning-community-network-for-beginners/index.html">Sayan Ghosh</a>
                            </div>
                                                                                                    <div class="rkit-blog-content">
                                <p class="rkit-blog-paragraph"> News A Learning Community Network for Beginners Author 2023/10/30 Training A condimentum vitae sapien pellentesque. Massa ultricies mi quis&hellip;                                </p>
                            </div>
                                                                                                    <div class="rkit-readmore-div">
                                <a class="rkit-readmore-btn" type="button" href="2023/10/30/a-learning-community-network-for-beginners/index.html">
                                                                        Read More                                                                    </a>
                            </div>
                                            </div>
						</div>
						<div class="col-md-3">
							<div class="rkit-image-container">
                                                        <a class="rkit-image-link" style="overflow: hidden;" href="2023/10/30/a-learning-community-network-for-beginners/index.html">
                                <img decoding="async" class="rkit-blog-img" src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/blog-3.4.jpg">
                            </a>
                                                            <!--<div class="rkit-float-metawrapper-date">
                                    <span><strong>30</strong>Oct</span>
                                </div>-->
                                                    </div>
                                        <div class="rkit-blog-body ">
                                                    <div class="rkit-metadata">
                                                            </div>
                                                                            <div class="rkit-blog-title-container">
                                <a class="rkit-blog-title" href="2023/10/30/a-learning-community-network-for-beginners/index.html">Ankan Das</a>
                            </div>
                                                                                                    <div class="rkit-blog-content">
                                <p class="rkit-blog-paragraph"> Sayan Ghosh - "Nexus Institute of Technology's focus on practical skills and industry connections was key to my success."&hellip;                                </p>
                            </div>
                                                                                                    <div class="rkit-readmore-div">
                                <a class="rkit-readmore-btn" type="button" href="2023/10/30/a-learning-community-network-for-beginners/index.html">
                                                                        Read More                                                                    </a>
                            </div>
                                            </div>
						</div>
					
                           
                
                
                
        </div>
        		</div>
				</div>
					</div>
				</div>
				</div>
		<footer itemscope="itemscope" itemtype="https://schema.org/WPFooter"><!--footer--><?php include "footer.php"?>		<div data-elementor-type="wp-post" data-elementor-id="2581" class="elementor elementor-2581"></div>
		</footer></div><!-- #page -->
<link rel='stylesheet' id='elementor-post-2530-css' href='<?=base_url("assets/");?>wp-content/uploads/sites/89/elementor/css/post-25306dda.css?ver=1716977899' media='all' />
<link rel='stylesheet' id='elementor-post-2581-css' href='<?=base_url("assets/");?>wp-content/uploads/sites/89/elementor/css/post-25816dda.css?ver=1716977899' media='all' />
<link rel='stylesheet' id='e-animations-css' href='<?=base_url("assets/");?>wp-content/plugins/elementor/assets/lib/animations/animations.min3cad.css?ver=3.21.8' media='all' />
<link rel='stylesheet' id='elementor-icons-rtmicons-css' href='<?=base_url("assets/");?>wp-content/plugins/rometheme-for-elementor/assets/css/rtmiconsc2d0.css?ver=1.4.4' media='all' />
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/rkit-navmenuc2d0.js?ver=1.4.4" id="navmenu-rkit-script-js"></script>
<script src="wp-content/plugins/rometheme-for-elementor/widgets/assets/js/social_sharec2d0.js?ver=1.4.4" id="social-share-script-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/running_textc2d0.js?ver=1.4.4" id="running-text-script-js"></script>
<script src="../../cdnjs.cloudflare.com/ajax/libs/Chart.js/3.5.1/chart.minc2d0.js?ver=1.4.4" id="chartjs-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/testimonial_carouselc2d0.js?ver=1.4.4" id="rkit-testimonial_carousel-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/tabsc2d0.js?ver=1.4.4" id="rkit-tabs-script-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/progressc2d0.js?ver=1.4.4" id="progress-script-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/rometheme-for-elementor/widgets/assets/js/counterc2d0.js?ver=1.4.4" id="rkit-counter-script-js"></script>
<script src="<?=base_url('assets/');?>wp-includes/js/jquery/ui/core.min3f14.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script id="qi-addons-for-elementor-script-js-extra">
var qodefQiAddonsGlobal = {"vars":{"adminBarHeight":0,"iconArrowLeft":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0.5\" y1=\"16\" x2=\"33.5\" y2=\"16\"\/><line x1=\"0.3\" y1=\"16.5\" x2=\"16.2\" y2=\"0.7\"\/><line x1=\"0\" y1=\"15.4\" x2=\"16.2\" y2=\"31.6\"\/><\/svg>","iconArrowRight":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0\" y1=\"16\" x2=\"33\" y2=\"16\"\/><line x1=\"17.3\" y1=\"0.7\" x2=\"33.2\" y2=\"16.5\"\/><line x1=\"17.3\" y1=\"31.6\" x2=\"33.5\" y2=\"15.4\"\/><\/svg>","iconClose":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" x=\"0px\" y=\"0px\" viewBox=\"0 0 9.1 9.1\" xml:space=\"preserve\"><g><path d=\"M8.5,0L9,0.6L5.1,4.5L9,8.5L8.5,9L4.5,5.1L0.6,9L0,8.5L4,4.5L0,0.6L0.6,0L4.5,4L8.5,0z\"\/><\/g><\/svg>"}};
</script>
<script src="<?=base_url('assets/');?>wp-content/plugins/qi-addons-for-elementor/assets/js/main.minba3a.js?ver=1.7.2" id="qi-addons-for-elementor-script-js"></script>
<script src="<?=base_url('assets/');?>wp-content/themes/hello-elementor/assets/js/hello-frontend.min41fe.js?ver=3.0.1" id="hello-theme-frontend-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/elementor/assets/js/webpack.runtime.min3cad.js?ver=3.21.8" id="elementor-webpack-runtime-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/elementor/assets/js/frontend-modules.min3cad.js?ver=3.21.8" id="elementor-frontend-modules-js"></script>
<script src="<?=base_url('assets/');?>wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min05da.js?ver=4.0.2" id="elementor-waypoints-js"></script>
<script id="elementor-frontend-js-before">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselWrapperAriaLabel":"Carousel | Horizontal scrolling: Arrow Left & Right","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.21.8","is_static":false,"experimentalFeatures":{"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"additional_custom_breakpoints":true,"container":true,"e_swiper_latest":true,"container_grid":true,"hello-theme-header-footer":true,"home_screen":true,"ai-layout":true,"landing-pages":true},"urls":{"assets":"https:\/\/hrkit.rometheme.pro\/zevone\/wp-content\/plugins\/elementor\/assets\/"},"swiperClass":"swiper","settings":{"page":[],"editorPreferences":[]},"kit":{"body_background_background":"classic","active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description","hello_header_logo_type":"title","hello_header_menu_layout":"horizontal","hello_footer_logo_type":"logo"}};
</script>
<script src="<?=base_url('assets/');?>wp-content/plugins/elementor/assets/js/frontend.min3cad.js?ver=3.21.8" id="elementor-frontend-js"></script>
<script src="<?=base_url('assets/');?>wp-includes/js/dist/vendor/wp-polyfill-inert.min0226.js?ver=3.1.2" id="wp-polyfill-inert-js"></script>
<script src="<?=base_url('assets/');?>wp-includes/js/dist/vendor/regenerator-runtime.min6c85.js?ver=0.14.0" id="regenerator-runtime-js"></script>
<script src="<?=base_url('assets/');?>wp-includes/js/dist/vendor/wp-polyfill.min2c7c.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script src="<?=base_url('assets/');?>wp-includes/js/dist/hooks.min2757.js?ver=2810c76e705dd1a53b18" id="wp-hooks-js"></script>
<script src="<?=base_url('assets/');?>wp-includes/js/dist/i18n.minc33c.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script src="<?=base_url('assets/');?>wp-content/plugins/qi-addons-for-elementor/inc/plugins/elementor/assets/js/elementor380f.js?ver=6.5.4" id="qi-addons-for-elementor-elementor-js"></script>
</body>


<!-- Mirrored from hrkit.rometheme.pro/zevone/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 08 Jun 2024 16:18:26 GMT -->
</html>