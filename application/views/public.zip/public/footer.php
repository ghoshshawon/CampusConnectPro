<footer itemscope="itemscope" itemtype="https://schema.org/WPFooter">		<div data-elementor-type="wp-post" data-elementor-id="2581" class="elementor elementor-2581">
				<div class="elementor-element elementor-element-3be0c05 e-flex e-con-boxed e-con e-parent" data-id="3be0c05" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-67cbf65 e-flex e-con-boxed e-con e-child" data-id="67cbf65" data-element_type="container">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-06e7c9f e-con-full e-flex e-con e-child" data-id="06e7c9f" data-element_type="container">
				<div class="elementor-element elementor-element-5db653c elementor-widget elementor-widget-image" data-id="5db653c" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
													<img width="300" height="115" src="<?=base_url('assets/');?>/wp-content/uploads/sites/89/2023/10/logo-zevone.png" class="attachment-full size-full wp-image-2565" alt="" />													</div>
				</div>
				<div class="elementor-element elementor-element-4558f4d elementor-widget elementor-widget-text-editor" data-id="4558f4d" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Thank you for exploring Nexus Institute of Technology. We are dedicated to empowering students with innovative education, hands-on learning, and a supportive community. Join us to achieve your academic and career goals. Stay connected and discover how NiT can be the catalyst for your future success.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-f173201 elementor-shape-rounded elementor-grid-0 e-grid-align-center elementor-widget elementor-widget-social-icons" data-id="f173201" data-element_type="widget" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper elementor-grid">
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-8e4e4b7" target="_blank">
						<span class="elementor-screen-only">Facebook</span>
						<i class="fab fa-facebook"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-9b29e8d" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<i class="fab fa-instagram"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-repeater-item-24974f6" target="_blank">
						<span class="elementor-screen-only">Twitter</span>
						<i class="fab fa-twitter"></i>					</a>
				</span>
							<span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-youtube elementor-repeater-item-48e7322" target="_blank">
						<span class="elementor-screen-only">Youtube</span>
						<i class="fab fa-youtube"></i>					</a>
				</span>
					</div>
				</div>
				</div>
				</div>
					</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-c933a18 e-flex e-con-boxed e-con e-parent" data-id="c933a18" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-afe3481 elementor-widget elementor-widget-text-editor" data-id="afe3481" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>© 2023 Nexus Institute of Technology</p>						</div>
				</div>
					</div>
				</div>
				</div>
		</footer>