<header id="masthead" itemscope="itemscope" itemtype="https://schema.org/WPHeader">		<div data-elementor-type="wp-post" data-elementor-id="2530" class="elementor elementor-2530">
				<div class="elementor-element elementor-element-6b11e55 e-flex e-con-boxed e-con e-parent" data-id="6b11e55" data-element_type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-3ede9cf e-con-full e-flex e-con e-child" data-id="3ede9cf" data-element_type="container">
				<div class="elementor-element elementor-element-68a1caa elementor-widget elementor-widget-image" data-id="68a1caa" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.21.0 - 26-05-2024 */
.elementor-widget-image{text-align:center}.elementor-widget-image a{display:inline-block}.elementor-widget-image a img[src$=".svg"]{width:48px}.elementor-widget-image img{vertical-align:middle;display:inline-block}</style>										<img src="<?=base_url('assets/');?>wp-content/uploads/sites/89/2023/10/logo-zevone.png" class="attachment-full size-full wp-image-2565" alt="" />													</div>
				</div>
				</div>
		<div class="elementor-element elementor-element-e529349 e-con-full e-flex e-con e-child" data-id="e529349" data-element_type="container">
				<div class="elementor-element elementor-element-c30a026 elementor-widget elementor-widget-rtm-navmenu" data-id="c30a026" data-element_type="widget" data-widget_type="rtm-navmenu.default">
				<div class="elementor-widget-container">
			        <div class="rkit-navmenu-container">
            <div id="rkit-hamburger-204513318" data-dropdown="rkit-dropdown-204513318" class="rkit-hamburger-tablet">
                <button class="rkit-btn-hamburger" onclick="open_dropdown('rkit-hamburger-' , 204513318 , 'tablet' , 'rkit-responsive-open-' )">
                    <div>
                        <i aria-hidden="true" class="rkit-icon-open rtmicon rtmicon-grid-rounds" id="rkit-icon-open204513318"></i>                        <i aria-hidden="true" class="rkit-icon-close rtmicon rtmicon-times" id="rkit-icon-close204513318" style="display:none"></i>                    </div>
                </button>
            </div>
            <div id="rkit-dropdown-204513318" class="rkit-navmenu rkit-responsive-menu rkit-responsive-tablet  rkit-navmenu-fullwidth">
                                    <div class="rkit-menu ">
                        <a class="rkit-menu-text " href="template-kit/homepage/index.html">HOME</a>
                    </div>
                                   <div class="rkit-dropdown">
                        <div class="rkit-menu ">
                            <a class="rkit-menu-text " href="#">
                               ABOUT                           </a>
                            <div onclick="dropdown_click.call(this)">
                                <i aria-hidden="true" class="rkit-submenu-icon fas fa-caret-down"></i>                            </div>
                        </div>
                        <div class="rkit-dropdown-submenu rkit-dropdown-click-tablet">
                                                                <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-service/index.html">ABOUT US</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-program/index.html">MESSAGE FROM FACULTY</a>
                                    </div> 

                                                        </div>
                    </div>

                    <div class="rkit-dropdown">
                        <div class="rkit-menu ">
                            <a class="rkit-menu-text " href="#">
                                CAMPUS LIFE                            </a>
                            <div onclick="dropdown_click.call(this)">
                                <i aria-hidden="true" class="rkit-submenu-icon fas fa-caret-down"></i>                            </div>
                        </div>
                        <div class="rkit-dropdown-submenu rkit-dropdown-click-tablet">
                                                                <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-service/index.html">INFRASTRUCTURE</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-program/index.html">STUDENT CENTRIC PROGRAMS</a>
                                    </div> 

                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-team/index.html">STUDENT CHAPTER</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="<?=base_url('fest');?>">COLLEGE FEST</a>
                                    </div>
                                                                   
                                                                    
                                                        </div>
                    </div>

                                    <div class="rkit-dropdown">
                        <div class="rkit-menu ">
                            <a class="rkit-menu-text " href="#">
                                LOGIN                            </a>
                            <div onclick="dropdown_click.call(this)">
                                <i aria-hidden="true" class="rkit-submenu-icon fas fa-caret-down"></i>                            </div>
                        </div>
                        <div class="rkit-dropdown-submenu rkit-dropdown-click-tablet">
                                                                <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-service/index.html">STUDENT LOGIN</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-program/index.html">EMPLOYEE LOGIN</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/single-program/index.html">ONLINE FEES PAYMENT</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-team/index.html">EXAM FORM FILL UP</a>
                                    </div>
                                                                    
                                                        </div>
                    </div>
                    <div class="rkit-dropdown">
                        <div class="rkit-menu ">
                            <a class="rkit-menu-text " href="#">
                                TRAINING &amp; PLACEMENT                            </a>
                            <div onclick="dropdown_click.call(this)">
                                <i aria-hidden="true" class="rkit-submenu-icon fas fa-caret-down"></i>                            </div>
                        </div>
                        <div class="rkit-dropdown-submenu rkit-dropdown-click-tablet">
                                                                <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-blog/index.html">OVERVIEW</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/single-blog/index.html">PLACEMENT</a>
                                    </div>
                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/single-blog/index.html">MULTIPLE OFFERS</a>
                                    </div>
                                                        </div>
                    </div>
                    <div class="rkit-menu ">
                        <a class="rkit-menu-text " href="template-kit/contact-us/index.html">CONTACT US</a>
                    </div>
                            </div>
            <div class="rkit-navmenu rkit-navmenu-tablet">
                                    <div class="rkit-menu ">
                        <a class="rkit-menu-text  " href="template-kit/homepage/index.html">HOME</a>
                    </div>
                                  <div class="rkit-dropdown">
                        <div class="rkit-menu " >
                            <a class="rkit-menu-text  "  href="#" >
                                ABOUT                            </a>
                            <i aria-hidden="true" class="rkit-submenu-icon fas fa-caret-down"></i>                        </div>
                        <div class="rkit-dropdown-submenu rkit-dropdown-hover-tablet">
                                                                <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-service/index.html">ABOUT US</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-program/index.html">MESSAGE FROM FACULTY</a>
                                    </div>
                                                                            
                                                        </div>
                    </div>
                    <div class="rkit-dropdown">
                        <div class="rkit-menu " >
                            <a class="rkit-menu-text  "  href="#" >
                                CAMPUS LIFE                            </a>
                            <i aria-hidden="true" class="rkit-submenu-icon fas fa-caret-down"></i>                        </div>
                        <div class="rkit-dropdown-submenu rkit-dropdown-hover-tablet">
                                                                <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-service/index.html">INFRASTRUCTURE</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-program/index.html">STUDENT CENTRIC PROGRAMS</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/single-program/index.html">STUDENT CHAPTER</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="<?=base_url('fest');?>">COLLEGE FEST</a>
                                    </div>

                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="<?=base_url('gallery');?>">GALLERY</a>
                                    </div>
                                                                
                                                        </div>
                    </div>

                                    <div class="rkit-dropdown">
                        <div class="rkit-menu " >
                            <a class="rkit-menu-text  "  href="#" >
                                LOGIN                            </a>
                            <i aria-hidden="true" class="rkit-submenu-icon fas fa-caret-down"></i>                        </div>
                        <div class="rkit-dropdown-submenu rkit-dropdown-hover-tablet">
                                                                <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-service/index.html">STUDENT LOGIN</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-program/index.html">EMPLOYEE LOGIN</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/single-program/index.html">ONLINE FEES PAYMENT</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-team/index.html">EXAM FORM FILL UP</a>
                                    </div>
                                                                
                                                        </div>
                    </div>
                                    <div class="rkit-dropdown">
                        <div class="rkit-menu " >
                            <a class="rkit-menu-text  "  href="#" >
                                TRAINING &amp; PLACEMENT                           </a>
                            <i aria-hidden="true" class="rkit-submenu-icon fas fa-caret-down"></i>                        </div>
                        <div class="rkit-dropdown-submenu rkit-dropdown-hover-tablet">
                                                                <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/our-blog/index.html">OVERVIEW</a>
                                    </div>
                                                                    <div class="rkit-submenu rkit-item-submenu rkit-submenu-item ">
                                        <a class="rkit-submenu-text " href="template-kit/single-blog/index.html">PLACEMENTS</a>
                                    </div>
                                                        </div>
                    </div>
                                    <div class="rkit-menu ">
                        <a class="rkit-menu-text  " href="template-kit/contact-us/index.html">CONTACT US</a>
                    </div>
                            </div>
        </div>
        		</div>
				</div>
				</div>
		<div class="elementor-element elementor-element-172a526 e-con-full e-flex e-con e-child"  data-id="172a526" data-element_type="container">
				<div class="elementor-element elementor-element-0a373ea elementor-align-right elementor-mobile-align-center elementor-widget elementor-widget-button" data-id="0a373ea" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-md" href="#">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-icon elementor-align-icon-right">
				<i aria-hidden="true" class="fas fa-rupee-sign"></i>			</span>
									<span class="elementor-button-text"> Pay</span>
					</span>

					</a>

		</div>

				</div>

				</div>

				</div>

				<div class="elementor-element elementor-element-172a526 e-con-full e-flex e-con e-child"  data-id="172a526" data-element_type="container" style="margin-left: 8vh;">
				<div class="elementor-element elementor-element-0a373ea elementor-align-right elementor-mobile-align-center elementor-widget elementor-widget-button" data-id="0a373ea" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a class="elementor-button elementor-button-link elementor-size-md" href="#">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-icon elementor-align-icon-right">
				<i aria-hidden="true" class="fas fa-poll"></i></span>
									<span class="elementor-button-text"> Result</span>
					</span>

					</a>

		</div>

				</div>

				</div>

				</div>


					</div>

				</div>

				</div>

		</header>	